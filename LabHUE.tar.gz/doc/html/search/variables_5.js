var searchData=
[
  ['largura',['largura',['../structMapa.html#a19fa95f6fab82c61c15026d6d079270a',1,'Mapa']]],
  ['linha',['linha',['../structBarco.html#a5acd39efb793a31efd6c21ba9790a910',1,'Barco']]]
];
