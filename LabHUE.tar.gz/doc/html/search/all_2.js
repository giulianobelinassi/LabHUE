var searchData=
[
  ['carrega_5fgraficos',['carrega_graficos',['../graficos_8h.html#a3c0bb25bf555e949460aa5af4a143275',1,'graficos.c']]],
  ['closegraph',['CloseGraph',['../xwc_8h.html#ac126eed74cb7b3c331dbfffd0790c1d6',1,'xwc.c']]],
  ['coluna',['coluna',['../structBarco.html#a3a34d5834d17d48496ce8f4e5dac6216',1,'Barco']]],
  ['coordenadas_5ftiro',['coordenadas_tiro',['../eventos_8h.html#a9719ffd0c81321c5e2dfe863ee314d0c',1,'eventos.h']]]
];
