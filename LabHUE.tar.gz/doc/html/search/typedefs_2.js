var searchData=
[
  ['window',['WINDOW',['../xwc_8h.html#ac4b6db67f625300fe335de44f7431ce3',1,'xwc.h']]]
];
