var searchData=
[
  ['barco',['Barco',['../structBarco.html',1,'Barco'],['../structGraficos.html#ad175afdffe9e08eb678a224220682967',1,'Graficos::barco()']]],
  ['barco_2eh',['barco.h',['../barco_8h.html',1,'']]],
  ['bussola',['bussola',['../structBarco.html#a682c01efed2c9624b4a65a2584deb83f',1,'Barco']]]
];
