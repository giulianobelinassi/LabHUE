var searchData=
[
  ['leia_5fmapa',['leia_mapa',['../mapa_8h.html#a6cfa5a68af55224c62b74b87f95ca4ac',1,'mapa.c']]]
];
