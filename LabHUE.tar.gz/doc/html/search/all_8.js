var searchData=
[
  ['largura',['largura',['../structMapa.html#a19fa95f6fab82c61c15026d6d079270a',1,'Mapa']]],
  ['leia_5fmapa',['leia_mapa',['../mapa_8h.html#a6cfa5a68af55224c62b74b87f95ca4ac',1,'mapa.c']]],
  ['linha',['linha',['../structBarco.html#a5acd39efb793a31efd6c21ba9790a910',1,'Barco']]]
];
