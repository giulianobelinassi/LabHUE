var searchData=
[
  ['readpic',['ReadPic',['../xwc_8h.html#aaf027cfe874a189f59f87c5c09bf58a9',1,'xwc.c']]],
  ['rema_5fbarco',['rema_barco',['../barco_8h.html#a5071582811fc4936d09452449c23ffaa',1,'barco.h']]]
];
