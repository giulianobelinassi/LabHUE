var searchData=
[
  ['freepic',['FreePic',['../xwc_8h.html#a66f9cfd7b4f0ed6cc8e7edecae06f6f2',1,'xwc.c']]]
];
