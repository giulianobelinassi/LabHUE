var searchData=
[
  ['barco',['barco',['../structGraficos.html#ad175afdffe9e08eb678a224220682967',1,'Graficos']]],
  ['bussola',['bussola',['../structBarco.html#a682c01efed2c9624b4a65a2584deb83f',1,'Barco']]]
];
