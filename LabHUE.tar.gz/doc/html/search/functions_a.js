var searchData=
[
  ['pega_5fseta_5fjanela',['pega_seta_janela',['../graficos_8h.html#a57567c1699571cc7278eae4ba2ce979b',1,'graficos.c']]],
  ['posiciona_5fbarco',['posiciona_barco',['../barco_8h.html#a418b8cc3294b8d48c2afe790c9d41a9e',1,'barco.h']]],
  ['putpic',['PutPic',['../xwc_8h.html#ad9041196571084a51a250caac43ae858',1,'xwc.c']]]
];
