var searchData=
[
  ['identifica_5falvo_5fatingido',['identifica_alvo_atingido',['../eventos_8h.html#a475e18165f8e10498809fa667dc8b18d',1,'eventos.c']]],
  ['inicializa_5fjanela',['inicializa_janela',['../graficos_8h.html#a5c6cbb6cb1de05c53deebd81d93493d2',1,'graficos.h']]],
  ['initgraph',['InitGraph',['../xwc_8h.html#a0a22bcdf5bf04b3acf40e8f68e05fbab',1,'xwc.c']]],
  ['initkbd',['InitKBD',['../xwc_8h.html#a2f84ed416e1901addb2bf824635bb327',1,'xwc.c']]]
];
