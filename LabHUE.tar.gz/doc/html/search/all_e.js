var searchData=
[
  ['setmask',['SetMask',['../xwc_8h.html#a3264df9ab1bd979c90860e39d6550d57',1,'xwc.c']]],
  ['sorteia',['SORTEIA',['../eventos_8h.html#a062db28171aea0e06d43bb752cf8e953',1,'eventos.h']]]
];
