var searchData=
[
  ['onda',['onda',['../structGraficos.html#a3719660b3d0fcea157c1154b4479206a',1,'Graficos']]]
];
