var searchData=
[
  ['tiro',['tiro',['../structGraficos.html#ad341905922298a6d98ab3ae7a634dd3f',1,'Graficos']]]
];
