var searchData=
[
  ['fbarco',['FBARCO',['../graficos_8h.html#a45218e00c9ceb9a4884f2f92fe5cccb6',1,'graficos.h']]],
  ['frames_5fbarco',['FRAMES_BARCO',['../graficos_8h.html#add40ed6ad3f2b712cc09022a7390c4b8',1,'graficos.h']]],
  ['freepic',['FreePic',['../xwc_8h.html#a66f9cfd7b4f0ed6cc8e7edecae06f6f2',1,'xwc.c']]]
];
