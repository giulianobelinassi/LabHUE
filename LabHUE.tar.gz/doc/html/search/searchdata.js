var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuwx",
  1: "bgmw",
  2: "begmx",
  3: "acdefgilmnprsuw",
  4: "abcdflmort",
  5: "mpw",
  6: "dfgs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estruturas de Dados",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições de Tipos",
  6: "Definições e Macros"
};

