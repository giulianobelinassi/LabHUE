var searchData=
[
  ['ganhou_5fjogo',['ganhou_jogo',['../eventos_8h.html#ac780f8ec0782c914c6a72fa389028d9e',1,'eventos.h']]],
  ['getdisplay',['GetDisplay',['../xwc_8h.html#a92d89dfa6f5d60386813a21edefcff67',1,'xwc.c']]],
  ['getdraw',['GetDraw',['../xwc_8h.html#ab864c6098762278bac9037d112055ca8',1,'xwc.h']]],
  ['getgc',['GetGC',['../xwc_8h.html#a6fbb610fdff4430d012a6d181eb40b20',1,'xwc.h']]],
  ['graficos',['Graficos',['../structGraficos.html',1,'']]],
  ['graficos_2eh',['graficos.h',['../graficos_8h.html',1,'']]]
];
