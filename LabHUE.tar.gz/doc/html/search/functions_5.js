var searchData=
[
  ['ganhou_5fjogo',['ganhou_jogo',['../eventos_8h.html#ac780f8ec0782c914c6a72fa389028d9e',1,'eventos.h']]],
  ['getdisplay',['GetDisplay',['../xwc_8h.html#a92d89dfa6f5d60386813a21edefcff67',1,'xwc.c']]]
];
