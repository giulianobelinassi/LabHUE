var searchData=
[
  ['newmask',['NewMask',['../xwc_8h.html#ae16789184f5c90444e6522e438d64c21',1,'xwc.c']]],
  ['newpic',['NewPic',['../xwc_8h.html#aab47c70a14d0c85f49e42312ab0a6ad3',1,'xwc.c']]],
  ['novo_5fmapa',['novo_mapa',['../mapa_8h.html#a7971967ec1b2a7fa4715e38c5d5b50f0',1,'mapa.c']]]
];
