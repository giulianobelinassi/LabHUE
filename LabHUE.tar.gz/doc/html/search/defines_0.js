var searchData=
[
  ['dim_5fx',['DIM_X',['../graficos_8h.html#af6ec22f9c3bd91bd252e29aebb461b11',1,'graficos.h']]],
  ['dim_5fy',['DIM_Y',['../graficos_8h.html#a5fa9a687139f39c5033eb566a9e7b6e1',1,'graficos.h']]]
];
