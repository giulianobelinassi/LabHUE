var searchData=
[
  ['mapa',['Mapa',['../structMapa.html',1,'']]],
  ['mapa_2eh',['mapa.h',['../mapa_8h.html',1,'']]],
  ['mask',['MASK',['../xwc_8h.html#a5a3b637d2418addf2fda4b39c1ace928',1,'xwc.h']]],
  ['matriz',['matriz',['../structMapa.html#a48671b56d1a91a65a1068e0884e398d0',1,'Mapa']]],
  ['mountpic',['MountPic',['../xwc_8h.html#af4a6df26c67f7b6b3351b05ad4a8451b',1,'xwc.c']]]
];
