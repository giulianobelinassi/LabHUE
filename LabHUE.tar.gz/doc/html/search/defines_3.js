var searchData=
[
  ['sorteia',['SORTEIA',['../eventos_8h.html#a062db28171aea0e06d43bb752cf8e953',1,'eventos.h']]]
];
