var searchData=
[
  ['getdraw',['GetDraw',['../xwc_8h.html#ab864c6098762278bac9037d112055ca8',1,'xwc.h']]],
  ['getgc',['GetGC',['../xwc_8h.html#a6fbb610fdff4430d012a6d181eb40b20',1,'xwc.h']]]
];
