var searchData=
[
  ['agua',['agua',['../structGraficos.html#a4739c08511b9601608df25199b2c8ea2',1,'Graficos']]],
  ['altura',['altura',['../structMapa.html#a34885c4a5559f3d93e05b7c225e19343',1,'Mapa']]]
];
